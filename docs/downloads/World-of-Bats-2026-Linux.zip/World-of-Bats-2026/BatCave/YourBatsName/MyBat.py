from Bat import Bat

class MyBat(Bat):    
    def run(self):
        self.setWingAppearance("00110011")
        self.setBodyAppearance("01000100")
        self.setColour((120,120,120))
        while True:
            self.setSpeed(1)
            result = self.ping()
            if(result["size"] == 0): self.turnRight(); self.turnLeft()
            	
