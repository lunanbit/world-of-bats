WORLD OF BATS 2026 - LINUX
==========================

Open the workshop website for the clearest step-by-step instructions.
A printable copy is included here:

  World-of-Bats-2026-Linux-Guide.pdf

Quick start from a Terminal:

  cd ~/Downloads/World-of-Bats-2026
  chmod +x run-on-linux.sh
  ./run-on-linux.sh
  python3 WorldOfBats.py

Press Q to close the bat world. Press Tab to show or hide scores.

If you see an error, leave the message on screen and ask a demonstrator.
